import React from 'react'
import Navebar from './Component/Navebar'
import Dashboard from './Component/Dashboard'

function MainPage() {
  return (
    <>
    
    <Navebar/>
    <Dashboard/>
    
    </>
  )
}

export default MainPage