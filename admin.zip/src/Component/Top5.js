import React from 'react'
import './All.css'
function Top5() {
  return (
    <>
    <div className='container-fluid  wan32 '>
        <div className='row '>
            <div className='col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 '>
                <div className='d-flex justify-content-between bg-white wan31 mt-5 wan38'>
                <div className='mt-3 mb-3'> 
                        <i class="fa-solid fa-laptop-file fs-4 me-3 ms-2"/>
                    <span className='fs-4 fw-light'>Easy dynamic table</span>
                </div>
                <div  className='mt-3 mb-3'>
                <i class="fa-solid fa-bars fs-4 mt-2 me-2"/>
                </div>
            </div>
            </div>
        </div>
        <div className='row'>
        <div className='col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 '>
            <div className='d-flex justify-content-between p-3 bg-white '>
            <div>
                Show <input type='number' placeholder='10' style={{width:"40px"}}/> entries
            </div>
            <div>
                Search <input type='text' placeholder=''/>
            </div>
        </div>
        </div>
        </div>
        <div className='row'>
        <div className='col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 '>
        <table class="table  table-striped table-hover  mb-5" >
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
      <th scope="col">Handle</th>
     
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
      <td>@mdo</td>
   
      
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
      <td>@mdo</td>
   
    </tr>
    <tr>
      <th scope="row">3</th>
      <td >Larry the Bird</td>
      <td>jjddd</td>
      <td>@twitter</td>
      <td>@mdo</td>

      
    </tr>
    <tr>
      <th scope="row">3</th>
      <td >Larry the Bird</td>
      <td>jjddd</td>
      <td>@twitter</td>
      <td>@mdo</td>
     
      
    </tr>
    <tr>
      <th scope="row">3</th>
      <td >Larry the Bird</td>
      <td>jjddd</td>
      <td>@twitter</td>
      <td>@mdo</td>
    
      
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
      <td>@mdo</td>
 
      
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
      <td>@mdo</td>
     
    </tr>
    <tr>
      <th scope="row">3</th>
      <td >Larry the Bird</td>
      <td>jjddd</td>
      <td>@twitter</td>
      <td>@mdo</td>
      
      
    </tr>
    <tr>
      <th scope="row">3</th>
      <td >Larry the Bird</td>
      <td>jjddd</td>
      <td>@twitter</td>
      <td>@mdo</td>
     
      
    </tr>
    <tr>
      <th scope="row">3</th>
      <td >Larry the Bird</td>
      <td>jjddd</td>
      <td>@twitter</td>
      <td>@mdo</td>
     
      
    </tr>
    
  </tbody>
</table>
<div class="loader me-5 " ></div>
        </div>
        </div>
    </div>
    
    
    </>
  )
}

export default Top5