import React from 'react'
import './Navebar.css';

function Navebar() {
  return (
<>
<nav class="navbar navbar-expand-lg bg-body-tertiary sticky-top">
  <div class="container-fluid">
  <h3 className='wan'><i>Archist</i></h3>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <li class="nav-item">
      <i class="fa-solid fa-bars fs-5 ms-5 wan2"/>
        </li>
        <li class="nav-item">
        <i class="fa-solid fa-magnifying-glass fs-5 ms-3 wan3"/>
        </li>
        <li class="nav-item">
        <span className='ms-2'><i class="fa-solid fa-gift mb-3 mx-1 wan5"/>Mega Menue</span>
        </li>
        <li class="nav-item">
        <span className='ms-2'><i class="fa-solid fa-4 mx-1 wan4"/>Setting</span>
        </li>
        <li class="nav-item">
        <span className='ms-2'><i class="fa-solid fa-clover mx-1 wan5 "/>Projects</span>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <div className='wan10 me-3'>
      <i class="fa-solid fa-braille  wan6 me-2" />
      <i class="fa-solid fa-bell fs-5 wan7 me-2"/>
      <i class="fa-solid fa-book-journal-whills wan8 fs-5 me-2"/>
      <i class="fa-solid fa-chart-simple wan9 fs-5 me-3"/>
      </div>
      <div className='d-flex wan12 me-4'>
        <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRUaD2-zKSjwRW5xykCOTLDbV5aaJvkxlQShQ&s' className='img-fluid rounded-circle me-3' style={{width:"35px",height:"35px"}}/>
        <h6 className='me-3'>Alina Maclourd<br/><span style={{fontWeight:"lighter"}}>Vp people manager</span></h6>
        <i class="fa-solid fa-file fs-4 wan11 mt-2 me-3"/>
      </div>
      <div>
      <i class="fa-solid fa-bars fs-4 mt-2 me-3"/>
      </div>
      </form>
    </div>
  </div>
</nav>
</>
  )
}

export default Navebar