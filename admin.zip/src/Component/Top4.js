import React from 'react'
import './All.css'
function Top4() {
  return (
    
    <>
    <div className='container-fluid wan32 p-4'>
        <div className='row'>
            <div className='col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3   '>
              <div className='bg-white p-3 wan33 wan37 wan38'>
                <h2>$874</h2>
                <span className=''>SalesLast Month</span>
                <img src='https://media.istockphoto.com/id/627089302/photo/abstract-background-based-on-stock-market-graphs.jpg?s=2048x2048&w=is&k=20&c=hu8uPq9e2RCSOzGj3T7BBXVCxBIfZ6NLkrmyv-IlkEk=' className='img-fluid mt-3 mb-2' style={{width:"300px",height:"180px"}}/>
              </div>
            </div>
            <div className='col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3'>
            <div className='bg-white p-3 wan34  wan37 wan38'>
                <h2>$874</h2>
                <span className=''>SalesLast Month</span>
                <img src='https://media.istockphoto.com/id/1294509728/vector/science-data-abstract-background.jpg?s=2048x2048&w=is&k=20&c=DiEfFMwqfnsbn_s24Yurl4KWgv_0cmcrUd5BOuGaoN0=' className='img-fluid mt-3 mb-2' style={{width:"300px",height:"180px"}}/>
              </div>
                </div>
                <div className='col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 '>
                <div className='bg-white p-3 wan35  wan37 wan38'>
                <h2>$874</h2>
                <span className=''>SalesLast Month</span>
                <img src='https://media.istockphoto.com/id/627089302/photo/abstract-background-based-on-stock-market-graphs.jpg?s=2048x2048&w=is&k=20&c=hu8uPq9e2RCSOzGj3T7BBXVCxBIfZ6NLkrmyv-IlkEk=' className='img-fluid mt-3 mb-2' style={{width:"300px",height:"180px"}}/>
              </div>
                </div>
                <div className='col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 '>
                <div className='bg-white p-3 wan36 wan38'>
                <h2>$874</h2>
                <span className=''>SalesLast Month</span>
                <img src='https://media.istockphoto.com/id/1294509728/vector/science-data-abstract-background.jpg?s=2048x2048&w=is&k=20&c=DiEfFMwqfnsbn_s24Yurl4KWgv_0cmcrUd5BOuGaoN0=' className='img-fluid mt-3 mb-2' style={{width:"300px",height:"180px"}}/>
              </div>
                </div>
        </div>
    </div>
    
    </>
  )
}

export default Top4