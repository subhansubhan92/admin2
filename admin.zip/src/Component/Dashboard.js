import React from 'react'
import Sidebar from './Sidebar'
import Top1 from './Top1'
import Top2 from './Top2'
import Top3 from './Top3'
import Top4 from './Top4'
import Top5 from './Top5'



function Dashboard() {
  return (
   <>
   <div className='container-fluid'>
    <div className='row'>
     <div className='col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 ' >
      <Sidebar/>
     </div>
     <div className='col-12 col-sm-12 col-md-10 col-lg-10 col-xl-10' >
     <Top1/>
     <Top2/>
     <Top3/>
     <Top4/>
     <Top5/>
</div>
    </div>
    </div>
   
   </>
  )
}

export default Dashboard