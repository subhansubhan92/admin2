import React, { useEffect, useState } from 'react'
import Navebar from './Navebar'
import Sidebar from './Sidebar'
import { Link } from 'react-router-dom'
import axios from 'axios';
import ApiUrl from './ApiUrl';
import { toast } from 'react-toastify';
import { Modal } from 'antd';

function Call() {
  const [Category, setCategory] = useState([]);
    const [call,setCall]=useState([]);
    const [forId,setForId]=useState([]);
    const [preVal,setPreVal]=useState([]);
    const [selectedOption, setSelectedOption] = useState('');
    const [selectCategory, setSelectCategory] = useState('');
    const handleType = (event) => {
      setSelectedOption(event.target.value);
  
  };
  
    const handleCategory = (event) => {
      setSelectCategory(event.target.value);
  
  };
  
    useEffect(()=>{
      axios.get(`${ApiUrl}/call/getAll`).then((res)=>{
        setCall(res.data.data);
      }).catch((error)=>{
        toast.warning(`please check your internet connection`);
      })
    },[]);
    // console.log(call,"=======================");
     
    
    const sendData = (values) => {
      const params = new FormData();
      params.append('audio', values?.audio?.files[0]);
      params.append("answer", selectedOption); 
      params.append("category", selectCategory);

      axios.put(`${ApiUrl}/call/update/${forId}`,params).then((res)=>{
        console.log(res.data);
        if(res.data.status==="ok"){
          toast.success('call is updated');
          axios.get(`${ApiUrl}/call/getAll`).then((res)=>{
            setCall(res.data.data);
          }).catch((error)=>{
            toast.warning(`please check your internet connection`);
          })
       
        }else{
          toast.error('something went wrong')
        }
      })
      .catch((error)=>{
        console.log("Error:",error);
      });
    }
 

    const onDeleteStudent = (id) =>{
      console.log('==========================',id)
    
      Modal.confirm({
        title:"Are you sure you want to delete?",
        onOk:()=>{
        
          axios.delete(`${ApiUrl}/call/delete/${id}`).then((res)=>{
            if(res.data.status==="ok"){
    
    
    toast.success("call deletd")
    
    axios.get(`${ApiUrl}/call/getAll`).then((res)=>{
      setCall(res.data.data);
    }).catch((error)=>{
      toast.warning(`please check your internet connection`);
    })
    
            }
          }).catch((Error)=>{
            console.log('please check your internet connection');
          })
    
    
    
    
        }
        })
      }


    useEffect(() => {
      axios.get(`${ApiUrl}/category/getAll`).then((res) => {
          setCategory(res.data.data)
      }).catch((Error) => {
        console.log('please check your internet connection');
      })
    }, [])

    const getAudioType = (url) => {
      const extension = url.split('.').pop().toLowerCase();
      switch (extension) {
        case 'mp3':
          return 'audio/mpeg';
        case 'ogg':
          return 'audio/ogg';
        case 'wav':
          return 'audio/wav';
        default:
          return 'audio/mpeg'; // Default to mp3 if the type is unknown
      }
    };
  
    return (
     <>
     <Navebar/>
     <div className='container-fluid '>
      <div className='row'>
       <div className='col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 ' >
        <Sidebar/>
       </div>
       <div className='col-12 col-sm-12 col-md-10 col-lg-10 col-xl-10 wani' >
        <div className='d-flex justify-content-end'>
       <Link to='/allcalls'><button class="button btn btn-primary ms-5 mt-5 me-5 text-end fs-5 text-center rounded" style={{width:"150px"}}>All Calls</button></Link>
       </div>
  <div className='p-4 ' style={{marginTop:"50px"}}>
  <table class="table  table-striped  table-hover" style={{border:"1px solid lightgray"}}>
    <thead>
      <tr>
        
        <th scope="col">id</th>
        <th>Audio</th>
        <th scope="col">Answer</th>
        <th scope="col">Category</th>
        <th>Action</th>
       
      </tr>
    </thead>
    <tbody>
      {call?.map((item,index)=>(
        <tr>
          
          <th>{index+1}</th>
          <td>
                  <audio controls>
                    <source src={`http://192.168.1.5:8000/${item.audio}`} type={getAudioType(item.audio)} />
                    Your browser does not support the audio element.
                  </audio>
                </td>
          <td>{item.answer}</td>
          <td>{item.category}</td>
          <td><span><i class="fa-solid fa-pen me-3 "          onClick={()=>{

setForId(item?.id)
axios.get(`${ApiUrl}/call/get/${item?.id}`).then((res)=>{
  setPreVal(res.data.data);  
}).catch((error)=>{
toast.warning(`please check your interest connection`);
})
        }}   style={{color:"green"}} data-bs-toggle="modal" data-bs-target="#exampleModal"/></span><span> <i class="fa-solid fa-trash" style={{color:"blue"}}    onClick={()=>{

          onDeleteStudent(item?.id)
          
                  }}/></span></td>
     
        </tr>
      ))}
    </tbody>
  </table>
  </div>
  </div>
      </div>
      </div>   
{/*  */}
<div class="modal fade"  id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form  class="row g-3  mt-5 p-5" onSubmit={(e)=>{
      e.preventDefault();
      sendData(e.target);
     }} >
              <div class="col-12">
      <label for="inputAddress" class="form-label fw-bold fs-5">Audio</label>
      <input type="file" class="form-control"  name="audio" placeholder="1234 Main St"/>
    </div>
    <select className="form-control" value={selectedOption} onChange={handleType}>
        <option>Select Type</option>
        <option>Connected to intended party</option>
        <option>Left a message</option>
        <option>Not the right person or no message</option>
</select>


<select className="form-control" value={selectCategory} onChange={handleCategory}>
        <option>Select Category</option>
        {Category?.map((item, index) => {
          return (
        <option>{item.categoryName}</option>
      );
    })}
</select>
    <div class="col-12">
      <button type="submit" class="btn btn-primary w-100bvcv fw-bold w-100 mt-3 fs-5">Submit</button>
    </div>
  </form>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

     </>
    )
  }
export default Call
