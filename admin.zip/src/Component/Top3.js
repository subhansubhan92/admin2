import React from 'react'
import './All.css'

function Top3() {
  return (
   <>
   <div className='container-fluid  p-4 wan32'>
    <div className='row d-flex wan31 '>
      <div className='col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 bg-white p-3'>
     <span className='fw-bold'>Total Order</span><br/>
     <span>Last year experience</span>
      </div>
    <div className='col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 bg-white  p-3'>
      <div className='d-flex'>
      <div>
<h2 className='mt-1 me-4 fw-bold text-success'>1869</h2>
</div>
<div>
<span className='fw-bold'>Follower</span><br/>
<span>People Interested</span>
</div>
</div>
</div>
<div className='col-12 col-sm-12 col-md-3 col-lg-3col-xl-3 bg-white  p-3'>
<div className='d-flex '>
      <div>
<h2 className='mt-1 me-4 fw-bold text-danger'>45,9</h2>
</div>
<div>
<span className='fw-bold'>Total Order</span><br/>
<span>Last Year experience</span>
</div>
</div>
</div>
<div className='col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 bg-white  p-3'>
<h2 className='text-xl-end text-sm-start text-md-end text-lg-end fw-bold text-success mt-1'>1896</h2>
</div>
    </div>
    <div className='row d-flex'>
      <div className='col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 bg-white  p-3'>
     <span className='fw-bold'>Total Order</span><br/>
     <span>Last year experience</span>
      </div>
    <div className='col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 bg-white  p-3'>
      <div className='d-flex'>
      <div>
<h2 className='mt-1 me-4 fw-bold text-primary'>$12.6k</h2>
</div>
<div>
<span className='fw-bold'>Client</span><br/>
<span>Total client profit</span>
</div>
</div>
</div>
<div className='col-12 col-sm-12 col-md-3 col-lg-3col-xl-3 bg-white  p-3'>
<div className='d-flex '>
      <div>
<h2 className='mt-1 me-4  fw-bold text-warning'>$3.1</h2>
</div>
<div>
<span className='fw-bold'>Client</span><br/>
<span>Total client profit</span>
</div>
</div>
</div>
<div className='col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 bg-white  p-3'>
<h2 className='text-xl-end text-sm-start text-md-end text-lg-end fw-bold text-primary mt-1'>$12.6k</h2>
</div>
    </div>
   </div>
   
   </>
  )
}

export default Top3