import React from 'react'
import './Sidebar.css'
import { Link } from 'react-router-dom'
function Sidebar() {
  return (
<>
<div className='wan28 '>
  <h6 className='text-primary mt-3 ms-3 '>MENU</h6>
  <div>
   <h6><i class="fa-solid fa-plane-up ms-4 mx-2 mb-2"/> Dashboard</h6>
   <div className='wan13 ' style={{marginLeft:'30px'}}>
    <Link to='/User'><h6 className='ms-3 mb-2'>User</h6></Link>
    <Link to='/call'><h6 className='ms-3  mb-2'>Call</h6></Link>
    <h6 className='ms-3  mb-2'>Sales</h6>
    <h6 className='ms-3  mb-2'>Minimal</h6>
    <h6 className='ms-3  mb-2'>CRM</h6>
   </div>
   <h6><i class="fa-solid fa-pager ms-4 mx-2 mb-2 "/>Pages</h6>
   <h6><i class="fa-brands fa-codepen ms-4 mx-2 mb-3"/>Application</h6>
   <h5 className='ms-2 text-primary'>UI Component</h5>
   <h6><i class="fa-regular fa-gem ms-4 mx-2 mt-3 mb-2"/>Element</h6>
   <h6><i class="fa-solid fa-car  ms-4 mx-2 mb-2"/>Component</h6>
   <h6><i class="fa-solid fa-table-list mx-2 ms-4 mb-2"/>Tables</h6>
   <h5 className='ms-2 text-primary'>Dashboard Widgets</h5>
   <h6><i class="fa-regular fa-gem ms-4 mx-2 mt-3 mb-2"/>Chart Boxes1</h6>
   <h6><i class="fa-regular fa-gem ms-4 mx-2 mb-2"/>Chart Boxes2</h6>
   <h6><i class="fa-regular fa-gem ms-4 mx-2 mb-2"/>Chart Boxes3</h6>
   <h6><i class="fa-regular fa-gem ms-4 mx-2 mb-2"/>Profile Boxes</h6>
   <h5 className='ms-2 text-primary'>Forms</h5>
   <h6><i class="fa-regular fa-gem ms-4 mx-2 mt-3 mb-2"/>Element</h6>
   <h6><i class="fa-regular fa-gem ms-4 mx-2 mb-2"/>Widgets</h6>
   <h5 className='ms-2 text-primary'>Charts</h5>
   <h6><i class="fa-regular fa-gem ms-4 mx-2 mt-3 mb-2"/>ChartUs</h6>
   <h6><i class="fa-regular fa-gem ms-4 mx-2 mb-2"/>Apex Charts</h6>
   <h6><i class="fa-regular fa-gem ms-4 mx-2 mb-2"/>Chart Sparklines</h6>
  </div>

</div>

</>
  )
}

export default Sidebar