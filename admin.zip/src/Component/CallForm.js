import React, { useEffect, useState } from 'react'
import Navebar from './Navebar'
import Sidebar from './Sidebar'
import axios from 'axios';
import ApiUrl from './ApiUrl';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router';


function CallForm() {
    const [Category, setCategory] = useState([]);
    const [selectedOption, setSelectedOption] = useState('');
    const [selectCategory, setSelectCategory] = useState('');
  
    const handleType = (event) => {
      setSelectedOption(event.target.value);
  
  };
  
    const handleCategory = (event) => {
      setSelectCategory(event.target.value);
  
  };
  useEffect(() => {
    axios.get(`${ApiUrl}/category/getAll`).then((res) => {
        setCategory(res.data.data)
    }).catch((Error) => {
      console.log('please check your internet connection');
    })
  }, [])


  console.log(Category,'================');
  
    const navigate=useNavigate();
    const sendData = (values) => {
        const params = new FormData();
        params.append('audio', values?.audio?.files[0]);
        params.append("answer", selectedOption); 
        params.append("category", selectCategory);
      
      axios.post(`${ApiUrl}/call/create`,params).then((res)=>{
        console.log(res.data);
        if(res.data.status==="ok"){
          toast.success('call is created');
          navigate("/call")
        }else{
          toast.error('something went wrong')
        }
      })
      .catch((error)=>{
        console.log("Error:",error);
      });
    }
 
    return (
    <>
    <Navebar/>
    <div className='container-fluid'>
      <div className='row'>
       <div className='col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 ' >
        <Sidebar/>
       </div>
       <div className='col-12 col-sm-12 col-md-10 col-lg-10 col-xl-10 wani' >
       <form  class="row g-3  mt-5 p-5" onSubmit={(e)=>{
      e.preventDefault();
      sendData(e.target);
     }} >
              <div class="col-12">
      <label for="inputAddress" class="form-label fw-bold fs-5">Audio</label>
      <input type="file" class="form-control"  name="audio" placeholder="1234 Main St"/>
    </div>
    <select className="form-control" value={selectedOption} onChange={handleType}>
        <option>Select Type</option>
        <option>Connected to intended party</option>
        <option>Left a message</option>
        <option>Not the right person or no message</option>
</select>


<select className="form-control" value={selectCategory} onChange={handleCategory}>
        <option>Select Category</option>
        {Category?.map((item, index) => {
          return (
        <option>{item.categoryName}</option>
      );
    })}
</select>
    <div class="col-12">
      <button type="submit" class="btn btn-primary w-100bvcv fw-bold w-100 mt-3 fs-5">Submit</button>
    </div>
  </form>
  </div>
      </div>
      </div>
  
  
  
  
    
    
    
    </>
    )
  }

export default CallForm