import React from 'react'
import './All.css'
function Top2() {
  return (
   <>
   
   <div className='container-fluid wan26'>
   <button class="btn wan18 me-3 ">Variation 1 </button><button class="btn wan18">Variation 2 </button>
    <div className='row '>
        <div className='col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12'>
          <div className='d-flex justify-content-between bg-white wan20 p-2 mt-4'>
            <div >
              <h4 className='fw-light'>Portfolio Performance</h4>
            </div>
            <div>
              <button className='wan19'>View All</button>
            </div>
        </div>
        </div>
    </div>
    <div className=''>
  <div className='col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 bg d-flex justify-content-between wan23 ' >
    <div className='d-flex  bg-white wan24' style={{width:"500px"}}>
    <div>
    <i class="fa-solid fa-computer wan21 fs-2 mt-4 ms-2 me-4"/>
    </div>
    <div className='mt-3 mb-3'>
      <span>Cash Deposit</span>
      <h1>1,7M</h1>
      <span>54.1% less earnings</span>
    </div>
    </div>
    <div className='d-flex wan24 bg-white ' style={{width:"500px"}}>
    <div>
    <i class="fa-solid fa-graduation-cap wan21 fs-2 mt-4 ms-2 me-4 bg-danger text-white"/>
    </div>
    <div className='mt-3 mb-3'>
      <span>Invested Devident</span>
      <h1>9M</h1>
      <span>Grow Rate 14.1% </span>
    </div>
    </div>
    <div className='d-flex wan24 bg-white ' style={{width:"500px"}}>
    <div>
    <i class="fa-regular fa-building wan21 fs-2 mt-4 ms-2 me-4 bg-success text-white"  / >
    </div>
    <div className='mt-3 mb-3'>
      <span>Capital Gains</span>
      <h1 className='text-success'>$563</h1>
      <span>Increased By 73.1% </span>
    </div>
    </div>
  </div>
 
    </div>
    <div className='row '>
      <div className='col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12   ' >
        <div className='d-flex justify-content-center bg-white mb-5' >
        <button className='wan25 mt-3 mb-3'><i class="fa-solid fa-chart-simple me-2"/>View Complete Report</button>
        </div>
      </div>
    </div>
   </div>
   
   </>
  )
}

export default Top2