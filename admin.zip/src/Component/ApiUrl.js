// const ApiUrl="http://localhost:8000/api"
const ApiUrl="http://192.168.1.5:8000/api"
export default ApiUrl; 