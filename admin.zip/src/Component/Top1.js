import React from 'react'
import './All.css'

function Top1() {
  return (
   <>
      <div className='container-fluid'>
    <div className='row wan14 p-3'>
        <div className='col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 d-flex justify-content-between '>
  
        <div class="icon-text d-flex">
            <div>
        <i class="fa-solid fa-car fs-2 wan15 ms-4 mt-3 wan15 mb-2 me-5"/>
        </div>
        <div className='mt-3'>
            <span className='fs-5'>Agriculture<br/> <span style={{fontSize:"15px"}}>This is an example dashboard created using build-in elementand Component</span></span>
            </div>
        </div>
        <div class="button-container">
        <i class="fa-regular fa-star  wan16 mt-3 mx-3"/>
            <button class="btn  wan17">Button </button>
       
    </div>
        </div>
    </div>
   </div>
   
   </>
  )
}

export default Top1