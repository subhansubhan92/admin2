
import './App.css';
import Dashboard from './Component/Dashboard';
import Navebar from './Component/Navebar';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import User from './Component/User'
import MainPage from './MainPage';
import UserForm from './Component/UserForm';
import Call from './Component/Call';
import CallForm from './Component/CallForm';


function App() {
  return (
   <>
 

   <BrowserRouter>
  <Routes>
  
    <Route path='/'  element={<MainPage/>}/>
    <Route path='/user'  element={<User/>}/>
    <Route path='/alluser'  element={<UserForm/>}/>
    <Route path='/call'  element={<Call/>}/>
    <Route path='/allcalls'  element={<CallForm/>}/>



  </Routes>
  </BrowserRouter>
   
   </>
  );
}

export default App;
